# Ref OS

**Ref OS** is a custom GUI-based operating system with native `.refx` app support, multitasking, a taskbar, and mouse interactions — all built from scratch.

## ✨ Features
- Bootable OS (GRUB-compatible)
- Custom GUI with draggable windows
- Clickable `.refx` apps
- Text input, multithreading, and app switching
- Optional Internet Stack (PCI, E1000, IPv4, UDP)

## 🧪 Live ISO
Download the latest `.iso` from [Releases](https://github.com/youruser/ref-os/releases) and boot in QEMU or on real hardware.

## 🛠️ Build & Run
```bash
./scripts/build.sh
./scripts/run-qemu.sh
```

## 🌍 Join the movement
This is just the beginning. Fork it, remix it, and help shape the future OS from scratch.

---

Made with 9∞ lost braincells and a dream.
