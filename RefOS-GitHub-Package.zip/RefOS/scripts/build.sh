#!/bin/bash
echo "[+] Building Ref OS..."
# Insert build commands here
echo "Build complete."