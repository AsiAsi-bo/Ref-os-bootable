#!/bin/bash
qemu-system-i386 -cdrom ../iso/RefOS-v0.1.iso